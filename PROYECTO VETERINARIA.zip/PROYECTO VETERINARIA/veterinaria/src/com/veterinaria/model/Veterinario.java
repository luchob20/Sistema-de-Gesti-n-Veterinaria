package com.veterinaria.model;

public class Veterinario extends Persona {
    private String especialidad;

    public Veterinario() {}

    public Veterinario(int id, String nombre, String telefono, String email, String especialidad) {
        super(id, nombre, telefono, email);
        this.especialidad = especialidad;
    }

    // Getter y Setter
    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}
