package com.veterinaria.model;

public class Dueno extends Persona {
    private String direccion;

    public Dueno() {}

    public Dueno(int id, String nombre, String telefono, String email, String direccion) {
        super(id, nombre, telefono, email);
        this.direccion = direccion;
    }

    // Getter y Setter
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
