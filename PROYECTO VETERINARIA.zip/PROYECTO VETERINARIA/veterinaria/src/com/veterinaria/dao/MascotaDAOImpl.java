package com.veterinaria.dao;

import com.veterinaria.model.Mascota;
import com.veterinaria.util.Conexion;
import java.sql.*;
import java.util.*;

public class MascotaDAOImpl implements MascotaDAO {

    @Override
    public void insertar(Mascota mascota) {
        String sql = "INSERT INTO mascotas(nombre, especie, raza, color, edad, peso, id_dueno) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mascota.getNombre());
            ps.setString(2, mascota.getEspecie());
            ps.setString(3, mascota.getRaza());
            ps.setString(4, mascota.getColor());
            ps.setInt(5, mascota.getEdad());
            ps.setDouble(6, mascota.getPeso());
            ps.setInt(7, mascota.getIdDueno());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actualizar(Mascota mascota) {
        String sql = "UPDATE mascotas SET nombre=?, especie=?, raza=?, color=?, edad=?, peso=?, id_dueno=? WHERE id_mascota=?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, mascota.getNombre());
            ps.setString(2, mascota.getEspecie());
            ps.setString(3, mascota.getRaza());
            ps.setString(4, mascota.getColor());
            ps.setInt(5, mascota.getEdad());
            ps.setDouble(6, mascota.getPeso());
            ps.setInt(7, mascota.getIdDueno());
            ps.setInt(8, mascota.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM mascotas WHERE id_mascota=?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Mascota buscarPorId(int id) {
        String sql = "SELECT * FROM mascotas WHERE id_mascota=?";
        Mascota m = null;
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                m = new Mascota();
                m.setId(rs.getInt("id_mascota"));
                m.setNombre(rs.getString("nombre"));
                m.setEspecie(rs.getString("especie"));
                m.setRaza(rs.getString("raza"));
                m.setColor(rs.getString("color"));
                m.setEdad(rs.getInt("edad"));
                m.setPeso(rs.getDouble("peso"));
                m.setIdDueno(rs.getInt("id_dueno"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return m;
    }

    @Override
    public List<Mascota> listar() {
        List<Mascota> lista = new ArrayList<>();
        String sql = "SELECT * FROM mascotas";
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Mascota m = new Mascota();
                m.setId(rs.getInt("id_mascota"));
                m.setNombre(rs.getString("nombre"));
                m.setEspecie(rs.getString("especie"));
                m.setRaza(rs.getString("raza"));
                m.setColor(rs.getString("color"));
                m.setEdad(rs.getInt("edad"));
                m.setPeso(rs.getDouble("peso"));
                m.setIdDueno(rs.getInt("id_dueno"));
                lista.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
