package com.veterinaria.dao;

import com.veterinaria.model.Mascota;
import java.util.List;

public interface MascotaDAO {
    void insertar(Mascota mascota);
    void actualizar(Mascota mascota);
    void eliminar(int id);
    Mascota buscarPorId(int id);
    List<Mascota> listar();
}
