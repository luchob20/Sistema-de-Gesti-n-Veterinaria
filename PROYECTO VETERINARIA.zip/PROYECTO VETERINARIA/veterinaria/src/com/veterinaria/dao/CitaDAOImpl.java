package com.veterinaria.dao;

import com.veterinaria.model.Cita;
import com.veterinaria.util.Conexion;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class CitaDAOImpl implements CitaDAO {

    @Override
    public void insertar(Cita cita) {
        String sql = "INSERT INTO citas (id_mascota, id_veterinario, fecha, hora, motivo) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexion.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cita.getIdMascota());
            ps.setInt(2, cita.getIdVeterinario());
            ps.setDate(3, Date.valueOf(cita.getFecha()));
            ps.setTime(4, Time.valueOf(cita.getHora()));
            ps.setString(5, cita.getMotivo());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar cita: " + e.getMessage(), e);
        }
    }

    @Override
    public void actualizar(Cita cita) {
        String sql = "UPDATE citas SET id_mascota=?, id_veterinario=?, fecha=?, hora=?, motivo=? WHERE id_cita=?";
        try (Connection conn = Conexion.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cita.getIdMascota());
            ps.setInt(2, cita.getIdVeterinario());
            ps.setDate(3, Date.valueOf(cita.getFecha()));
            ps.setTime(4, Time.valueOf(cita.getHora()));
            ps.setString(5, cita.getMotivo());
            ps.setInt(6, cita.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar cita: " + e.getMessage(), e);
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM citas WHERE id_cita=?";
        try (Connection conn = Conexion.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar cita: " + e.getMessage(), e);
        }
    }

    @Override
    public Cita buscar(int id) {
        String sql = "SELECT * FROM citas WHERE id_cita=?";
        try (Connection conn = Conexion.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Cita c = new Cita();
                c.setId(rs.getInt("id_cita"));
                c.setIdMascota(rs.getInt("id_mascota"));
                c.setIdVeterinario(rs.getInt("id_veterinario"));
                c.setFecha(rs.getDate("fecha").toLocalDate());
                c.setHora(rs.getTime("hora").toLocalTime());
                c.setMotivo(rs.getString("motivo"));
                return c;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar cita: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<Cita> listar() {
        List<Cita> lista = new ArrayList<>();
        String sql = "SELECT * FROM citas ORDER BY fecha DESC";
        try (Connection conn = Conexion.conectar();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Cita c = new Cita();
                c.setId(rs.getInt("id_cita"));
                c.setIdMascota(rs.getInt("id_mascota"));
                c.setIdVeterinario(rs.getInt("id_veterinario"));
                c.setFecha(rs.getDate("fecha").toLocalDate());
                c.setHora(rs.getTime("hora").toLocalTime());
                c.setMotivo(rs.getString("motivo"));
                lista.add(c);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar citas: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public List<Cita> listarPorMascota(int idMascota) {
        List<Cita> lista = new ArrayList<>();
        String sql = "SELECT * FROM citas WHERE id_mascota=? ORDER BY fecha DESC";
        try (Connection conn = Conexion.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idMascota);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cita c = new Cita();
                c.setId(rs.getInt("id_cita"));
                c.setIdMascota(rs.getInt("id_mascota"));
                c.setIdVeterinario(rs.getInt("id_veterinario"));
                c.setFecha(rs.getDate("fecha").toLocalDate());
                c.setHora(rs.getTime("hora").toLocalTime());
                c.setMotivo(rs.getString("motivo"));
                lista.add(c);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar citas por mascota: " + e.getMessage(), e);
        }
        return lista;
    }
}
