package com.veterinaria.dao;

import com.veterinaria.model.Veterinario;
import java.util.List;

public interface VeterinarioDAO {
    void insertar(Veterinario veterinario);
    void actualizar(Veterinario veterinario);
    void eliminar(int id);
    Veterinario buscarPorId(int id);
    List<Veterinario> listar();
}
