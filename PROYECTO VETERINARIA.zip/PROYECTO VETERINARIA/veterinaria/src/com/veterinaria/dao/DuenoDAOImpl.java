package com.veterinaria.dao;

import com.veterinaria.model.Dueno;
import com.veterinaria.util.Conexion;
import java.sql.*;
import java.util.*;

public class DuenoDAOImpl implements DuenoDAO {

    @Override
    public void insertar(Dueno dueno) {
        String sql = "INSERT INTO duenos(nombre, telefono, email, direccion) VALUES (?, ?, ?, ?)";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, dueno.getNombre());
            ps.setString(2, dueno.getTelefono());
            ps.setString(3, dueno.getEmail());
            ps.setString(4, dueno.getDireccion());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actualizar(Dueno dueno) {
        String sql = "UPDATE duenos SET nombre=?, telefono=?, email=?, direccion=? WHERE id_dueno=?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, dueno.getNombre());
            ps.setString(2, dueno.getTelefono());
            ps.setString(3, dueno.getEmail());
            ps.setString(4, dueno.getDireccion());
            ps.setInt(5, dueno.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM duenos WHERE id_dueno=?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Dueno buscarPorId(int id) {
        String sql = "SELECT * FROM duenos WHERE id_dueno=?";
        Dueno d = null;
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                d = new Dueno();
                d.setId(rs.getInt("id_dueno"));
                d.setNombre(rs.getString("nombre"));
                d.setTelefono(rs.getString("telefono"));
                d.setEmail(rs.getString("email"));
                d.setDireccion(rs.getString("direccion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return d;
    }

    @Override
    public List<Dueno> listar() {
        List<Dueno> lista = new ArrayList<>();
        String sql = "SELECT * FROM duenos";
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Dueno d = new Dueno();
                d.setId(rs.getInt("id_dueno"));
                d.setNombre(rs.getString("nombre"));
                d.setTelefono(rs.getString("telefono"));
                d.setEmail(rs.getString("email"));
                d.setDireccion(rs.getString("direccion"));
                lista.add(d);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

