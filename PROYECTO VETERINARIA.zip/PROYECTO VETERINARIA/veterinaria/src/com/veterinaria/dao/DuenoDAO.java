package com.veterinaria.dao;

import com.veterinaria.model.Dueno;
import java.util.List;

public interface DuenoDAO {
    void insertar(Dueno dueno);
    void actualizar(Dueno dueno);
    void eliminar(int id);
    Dueno buscarPorId(int id);
    List<Dueno> listar();
}
