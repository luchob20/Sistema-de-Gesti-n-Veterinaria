package com.veterinaria.dao;

import com.veterinaria.model.Veterinario;
import com.veterinaria.util.Conexion;
import java.sql.*;
import java.util.*;

public class VeterinarioDAOImpl implements VeterinarioDAO {

    @Override
    public void insertar(Veterinario veterinario) {
        String sql = "INSERT INTO veterinarios(nombre, telefono, email, especialidad) VALUES (?, ?, ?, ?)";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, veterinario.getNombre());
            ps.setString(2, veterinario.getTelefono());
            ps.setString(3, veterinario.getEmail());
            ps.setString(4, veterinario.getEspecialidad());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actualizar(Veterinario veterinario) {
        String sql = "UPDATE veterinarios SET nombre=?, telefono=?, email=?, especialidad=? WHERE id_veterinario=?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, veterinario.getNombre());
            ps.setString(2, veterinario.getTelefono());
            ps.setString(3, veterinario.getEmail());
            ps.setString(4, veterinario.getEspecialidad());
            ps.setInt(5, veterinario.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM veterinarios WHERE id_veterinario=?";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Veterinario buscarPorId(int id) {
        String sql = "SELECT * FROM veterinarios WHERE id_veterinario=?";
        Veterinario v = null;
        try (Connection conn = Conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                v = new Veterinario();
                v.setId(rs.getInt("id_veterinario"));
                v.setNombre(rs.getString("nombre"));
                v.setTelefono(rs.getString("telefono"));
                v.setEmail(rs.getString("email"));
                v.setEspecialidad(rs.getString("especialidad"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return v;
    }

    @Override
    public List<Veterinario> listar() {
        List<Veterinario> lista = new ArrayList<>();
        String sql = "SELECT * FROM veterinarios";
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Veterinario v = new Veterinario();
                v.setId(rs.getInt("id_veterinario"));
                v.setNombre(rs.getString("nombre"));
                v.setTelefono(rs.getString("telefono"));
                v.setEmail(rs.getString("email"));
                v.setEspecialidad(rs.getString("especialidad"));
                lista.add(v);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
