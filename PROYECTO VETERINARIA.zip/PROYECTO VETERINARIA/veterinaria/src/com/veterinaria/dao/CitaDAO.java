package com.veterinaria.dao;

import com.veterinaria.model.Cita;
import java.util.List;

public interface CitaDAO {
    void insertar(Cita cita);
    void actualizar(Cita cita);
    void eliminar(int id);
    Cita buscar(int id);
    List<Cita> listar();
    List<Cita> listarPorMascota(int idMascota);
}
