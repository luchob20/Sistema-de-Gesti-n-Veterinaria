package com.veterinaria.ui;

import com.veterinaria.dao.CitaDAO;
import com.veterinaria.dao.CitaDAOImpl;
import com.veterinaria.dao.MascotaDAO;
import com.veterinaria.dao.MascotaDAOImpl;
import com.veterinaria.dao.VeterinarioDAO;
import com.veterinaria.dao.VeterinarioDAOImpl;
import com.veterinaria.model.Cita;
import com.veterinaria.model.Mascota;
import com.veterinaria.model.Veterinario;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrmCitas extends javax.swing.JFrame {

    CitaDAO citaDAO = new CitaDAOImpl();
    MascotaDAO mascotaDAO = new MascotaDAOImpl();
    VeterinarioDAO veterinarioDAO = new VeterinarioDAOImpl();
    DefaultTableModel modeloTabla = new DefaultTableModel();

    public FrmCitas() {
        initComponents();
        setLocationRelativeTo(null);
        cargarComboMascotas();
        cargarComboVeterinarios();
        cargarTabla();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        comboMascota = new javax.swing.JComboBox<>();
        comboVeterinario = new javax.swing.JComboBox<>();
        txtFecha = new javax.swing.JTextField();
        txtHora = new javax.swing.JTextField();
        txtMotivo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCitas = new javax.swing.JTable();
        btnGuardar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gestión de Citas");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Mascota:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel2.setText("Veterinario:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        jLabel3.setText("Fecha (dd-MM-yyyy):");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        jLabel5.setText("Hora (HH:mm):");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, -1, -1));

        jLabel4.setText("Motivo:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        getContentPane().add(comboMascota, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 200, -1));
        getContentPane().add(comboVeterinario, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, 200, -1));
        getContentPane().add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 200, -1));
        getContentPane().add(txtHora, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 200, -1));
        getContentPane().add(txtMotivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 200, -1));

        tablaCitas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"ID", "Mascota", "Veterinario", "Fecha", "Hora", "Motivo"}
        ));
        tablaCitas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCitasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCitas);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 480, 150));

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(evt -> btnGuardarActionPerformed(evt));
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, -1, -1));

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(evt -> btnActualizarActionPerformed(evt));
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, -1, -1));

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(evt -> btnEliminarActionPerformed(evt));
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, -1, -1));

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(evt -> btnLimpiarActionPerformed(evt));
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 380, -1, -1));

        pack();
    }

    private void cargarComboMascotas() {
        try {
            List<Mascota> lista = mascotaDAO.listar();
            comboMascota.removeAllItems();
            for (Mascota m : lista) {
                comboMascota.addItem(m.getId() + " - " + m.getNombre());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar mascotas: " + e.getMessage());
        }
    }

    private void cargarComboVeterinarios() {
        try {
            List<Veterinario> lista = veterinarioDAO.listar();
            comboVeterinario.removeAllItems();
            for (Veterinario v : lista) {
                comboVeterinario.addItem(v.getId() + " - " + v.getNombre() + " (" + v.getEspecialidad() + ")");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar veterinarios: " + e.getMessage());
        }
    }

    private void cargarTabla() {
        modeloTabla = new DefaultTableModel(new String[]{"ID", "Mascota", "Veterinario", "Fecha", "Hora", "Motivo"}, 0);
        try {
            List<Cita> lista = citaDAO.listar();
            for (Cita c : lista) {
                modeloTabla.addRow(new Object[]{
                    c.getId(),
                    c.getIdMascota(),
                    c.getIdVeterinario(),
                    c.getFecha(),
                    c.getHora(),
                    c.getMotivo()
                });
            }
            tablaCitas.setModel(modeloTabla);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar citas: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        txtFecha.setText("");
        txtHora.setText("");
        txtMotivo.setText("");
        comboMascota.setSelectedIndex(-1);
        comboVeterinario.setSelectedIndex(-1);
    }

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int idMascota = Integer.parseInt(comboMascota.getSelectedItem().toString().split(" - ")[0]);
            int idVeterinario = Integer.parseInt(comboVeterinario.getSelectedItem().toString().split(" - ")[0]);
            LocalDate fecha = LocalDate.parse(txtFecha.getText(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            LocalTime hora = LocalTime.parse(txtHora.getText(), DateTimeFormatter.ofPattern("HH:mm"));
            String motivo = txtMotivo.getText();

            Cita c = new Cita();
            c.setIdMascota(idMascota);
            c.setIdVeterinario(idVeterinario);
            c.setFecha(fecha);
            c.setHora(hora);
            c.setMotivo(motivo);

            citaDAO.insertar(c);
            JOptionPane.showMessageDialog(this, "Cita registrada correctamente");
            cargarTabla();
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage());
        }
    }

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int fila = tablaCitas.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione una cita para actualizar.");
                return;
            }

            int id = Integer.parseInt(tablaCitas.getValueAt(fila, 0).toString());
            int idMascota = Integer.parseInt(comboMascota.getSelectedItem().toString().split(" - ")[0]);
            int idVeterinario = Integer.parseInt(comboVeterinario.getSelectedItem().toString().split(" - ")[0]);
            LocalDate fecha = LocalDate.parse(txtFecha.getText(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            LocalTime hora = LocalTime.parse(txtHora.getText(), DateTimeFormatter.ofPattern("HH:mm"));
            String motivo = txtMotivo.getText();

            Cita c = new Cita();
            c.setId(id);
            c.setIdMascota(idMascota);
            c.setIdVeterinario(idVeterinario);
            c.setFecha(fecha);
            c.setHora(hora);
            c.setMotivo(motivo);

            citaDAO.actualizar(c);
            JOptionPane.showMessageDialog(this, "Cita actualizada correctamente");
            cargarTabla();
            limpiarCampos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + e.getMessage());
        }
    }

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int fila = tablaCitas.getSelectedRow();
            if (fila == -1) {
                JOptionPane.showMessageDialog(this, "Seleccione una cita para eliminar.");
                return;
            }

            int id = Integer.parseInt(tablaCitas.getValueAt(fila, 0).toString());
            int confirm = JOptionPane.showConfirmDialog(this, "¿Desea eliminar esta cita?", "Confirmar", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                citaDAO.eliminar(id);
                JOptionPane.showMessageDialog(this, "Cita eliminada correctamente");
                cargarTabla();
                limpiarCampos();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {
        limpiarCampos();
    }

    private void tablaCitasMouseClicked(java.awt.event.MouseEvent evt) {
        int fila = tablaCitas.getSelectedRow();
        if (fila >= 0) {
            txtFecha.setText(tablaCitas.getValueAt(fila, 3).toString());
            txtHora.setText(tablaCitas.getValueAt(fila, 4).toString());
            txtMotivo.setText(tablaCitas.getValueAt(fila, 5).toString());
        }
    }

    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> comboMascota;
    private javax.swing.JComboBox<String> comboVeterinario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaCitas;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtHora;
    private javax.swing.JTextField txtMotivo;
}
