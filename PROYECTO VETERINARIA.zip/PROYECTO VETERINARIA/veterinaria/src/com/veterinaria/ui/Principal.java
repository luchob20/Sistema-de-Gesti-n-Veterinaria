package com.veterinaria.ui;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class Principal extends JFrame {

    public Principal() {
        setTitle("Sistema de Veterinaria");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel principal
        JPanel panel = new JPanel(new GridLayout(2, 3, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        // === ICONOS ===
        JButton btnDuenos = crearBoton("Gestionar Dueños", "/iconos/GestionarDuenos.png");
        JButton btnMascotas = crearBoton("Gestionar Mascotas", "/iconos/GestionarMascotas.png");
        JButton btnCitas = crearBoton("Gestionar Citas", "/iconos/GestionarCitas.png");
        JButton btnVeterinarios = crearBoton("Veterinarios", "/iconos/GestionarVeterinarios.png");
        JButton btnAyuda = crearBoton("Ayuda", "/iconos/Ayuda.png");

        // === EVENTOS ===
        btnDuenos.addActionListener(e -> new FrmDueno().setVisible(true));
        btnMascotas.addActionListener(e -> new FrmMascotas().setVisible(true));
        btnCitas.addActionListener(e -> new FrmCitas().setVisible(true));
        btnVeterinarios.addActionListener(e -> new FrmVeterinarios().setVisible(true));
        btnAyuda.addActionListener(e -> new FrmAcercaDe().setVisible(true));

        // === AGREGAR AL PANEL ===
        panel.add(btnDuenos);
        panel.add(btnMascotas);
        panel.add(btnCitas);
        panel.add(btnVeterinarios);
        panel.add(btnAyuda);

        add(panel, BorderLayout.CENTER);
    }

    private JButton crearBoton(String texto, String rutaIcono) {
        URL url = getClass().getResource(rutaIcono);
        if (url == null) {
            System.out.println("⚠️ No se encontró el icono: " + rutaIcono);
            return new JButton(texto);
        }

        ImageIcon icono = new ImageIcon(url);
        JButton boton = new JButton(texto, icono);
        boton.setHorizontalTextPosition(SwingConstants.CENTER);
        boton.setVerticalTextPosition(SwingConstants.BOTTOM);
        boton.setFocusPainted(false);
        boton.setBackground(new Color(230, 240, 250));
        boton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        return boton;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Principal().setVisible(true));
    }
}
