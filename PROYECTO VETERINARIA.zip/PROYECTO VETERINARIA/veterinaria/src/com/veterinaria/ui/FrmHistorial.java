package com.veterinaria.ui;

import com.veterinaria.dao.CitaDAOImpl;
import com.veterinaria.dao.MascotaDAOImpl;
import com.veterinaria.model.Cita;
import com.veterinaria.model.Mascota;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmHistorial extends JFrame {

    private JComboBox<Mascota> comboMascota;
    private JTable tabla;
    private CitaDAOImpl dao = new CitaDAOImpl();
    private MascotaDAOImpl daoMascota = new MascotaDAOImpl();

    public FrmHistorial() {
        setTitle("Historial de Citas");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lblMascota = new JLabel("Mascota:");
        lblMascota.setBounds(20, 20, 80, 25);
        add(lblMascota);

        comboMascota = new JComboBox<>();
        comboMascota.setBounds(100, 20, 200, 25);
        add(comboMascota);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(320, 20, 100, 25);
        add(btnBuscar);

        tabla = new JTable();
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(20, 60, 640, 280);
        add(scroll);

        cargarComboMascotas();

        btnBuscar.addActionListener(e -> cargarHistorial());
    }

    private void cargarComboMascotas() {
        comboMascota.removeAllItems();
        List<Mascota> lista = daoMascota.listar();
        for (Mascota m : lista) {
            comboMascota.addItem(m);
        }
    }

    private void cargarHistorial() {
        Mascota mascota = (Mascota) comboMascota.getSelectedItem();
        if (mascota == null) return;

        String[] columnas = {"ID", "Fecha", "Hora", "Motivo", "Veterinario"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        List<Cita> lista = dao.listarPorMascota(mascota.getId());
        for (Cita c : lista) {
            Object[] fila = {c.getId(), c.getFecha(), c.getHora(), c.getMotivo(), c.getIdVeterinario()};
            modelo.addRow(fila);
        }
        tabla.setModel(modelo);
    }
}

