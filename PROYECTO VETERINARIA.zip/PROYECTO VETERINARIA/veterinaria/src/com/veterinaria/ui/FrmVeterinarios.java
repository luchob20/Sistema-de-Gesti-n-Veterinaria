package com.veterinaria.ui;

import com.veterinaria.dao.VeterinarioDAOImpl;
import com.veterinaria.model.Veterinario;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmVeterinarios extends JFrame {

    private JTable tabla;
    private JTextField txtNombre, txtTelefono, txtEmail, txtEspecialidad;
    private VeterinarioDAOImpl dao = new VeterinarioDAOImpl();
    private int idSeleccionado = -1;

    public FrmVeterinarios() {
        setTitle("Gestión de Veterinarios");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 20, 80, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(100, 20, 150, 25);
        add(txtNombre);

        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(20, 55, 80, 25);
        add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(100, 55, 150, 25);
        add(txtTelefono);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(20, 90, 80, 25);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(100, 90, 150, 25);
        add(txtEmail);

        JLabel lblEspecialidad = new JLabel("Especialidad:");
        lblEspecialidad.setBounds(20, 125, 80, 25);
        add(lblEspecialidad);

        txtEspecialidad = new JTextField();
        txtEspecialidad.setBounds(100, 125, 150, 25);
        add(txtEspecialidad);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(280, 20, 100, 25);
        add(btnAgregar);

        JButton btnEditar = new JButton("Editar");
        btnEditar.setBounds(280, 55, 100, 25);
        add(btnEditar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(280, 90, 100, 25);
        add(btnEliminar);

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(280, 125, 100, 25);
        add(btnLimpiar);

        tabla = new JTable();
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(20, 170, 640, 180);
        add(scroll);

        cargarTabla();

        btnAgregar.addActionListener(e -> agregar());
        btnEditar.addActionListener(e -> editar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiar());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() != -1) {
                idSeleccionado = (int) tabla.getValueAt(tabla.getSelectedRow(), 0);
                txtNombre.setText(tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                txtTelefono.setText(tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                txtEmail.setText(tabla.getValueAt(tabla.getSelectedRow(), 3).toString());
                txtEspecialidad.setText(tabla.getValueAt(tabla.getSelectedRow(), 4).toString());
            }
        });
    }

    private void cargarTabla() {
        String[] columnas = {"ID", "Nombre", "Teléfono", "Email", "Especialidad"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        List<Veterinario> lista = dao.listar();
        for (Veterinario v : lista) {
            Object[] fila = {v.getId(), v.getNombre(), v.getTelefono(), v.getEmail(), v.getEspecialidad()};
            modelo.addRow(fila);
        }
        tabla.setModel(modelo);
    }

    private void agregar() {
        Veterinario v = new Veterinario();
        v.setNombre(txtNombre.getText());
        v.setTelefono(txtTelefono.getText());
        v.setEmail(txtEmail.getText());
        v.setEspecialidad(txtEspecialidad.getText());
        dao.insertar(v);
        cargarTabla();
        limpiar();
    }

    private void editar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un registro");
            return;
        }
        Veterinario v = new Veterinario();
        v.setId(idSeleccionado);
        v.setNombre(txtNombre.getText());
        v.setTelefono(txtTelefono.getText());
        v.setEmail(txtEmail.getText());
        v.setEspecialidad(txtEspecialidad.getText());
        dao.actualizar(v);
        cargarTabla();
        limpiar();
    }

    private void eliminar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un registro");
            return;
        }
        dao.eliminar(idSeleccionado);
        cargarTabla();
        limpiar();
    }

    private void limpiar() {
        txtNombre.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtEspecialidad.setText("");
        idSeleccionado = -1;
    }
}
