package com.veterinaria.ui;

import javax.swing.*;

public class FrmAcercaDe extends JFrame {

    public FrmAcercaDe() {
        setTitle("Acerca de");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JTextArea txtInfo = new JTextArea();
        txtInfo.setEditable(false);
        txtInfo.setText(
            "Sistema de Gestión Veterinaria\n\n" +
            "Proyecto desarrollado en Java con PostgreSQL\n\n" +
            "Autores:\n" +
            "Luis Eduardo\n" +
            "Carlos Andrés Acevedo\n" +
            "Jonathan Andrés Bonilla\n\n" +
            "Unidades Tecnológicas de Santander\n" +
            "2025"
        );
        txtInfo.setBounds(30, 30, 330, 200);
        add(txtInfo);
    }
}
