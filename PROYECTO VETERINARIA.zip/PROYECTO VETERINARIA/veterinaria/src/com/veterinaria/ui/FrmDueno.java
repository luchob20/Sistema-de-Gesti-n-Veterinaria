package com.veterinaria.ui;

import com.veterinaria.dao.DuenoDAOImpl;
import com.veterinaria.model.Dueno;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FrmDueno extends JFrame {

    private JTable tabla;
    private JTextField txtNombre, txtTelefono, txtEmail, txtDireccion;
    private DuenoDAOImpl dao = new DuenoDAOImpl();
    private int idSeleccionado = -1;

    public FrmDueno() {
        setTitle("Gestión de Dueños");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 20, 80, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(100, 20, 150, 25);
        add(txtNombre);

        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(20, 55, 80, 25);
        add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(100, 55, 150, 25);
        add(txtTelefono);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(20, 90, 80, 25);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(100, 90, 150, 25);
        add(txtEmail);

        JLabel lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(20, 125, 80, 25);
        add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(100, 125, 150, 25);
        add(txtDireccion);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(280, 20, 100, 25);
        add(btnAgregar);

        JButton btnEditar = new JButton("Editar");
        btnEditar.setBounds(280, 55, 100, 25);
        add(btnEditar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(280, 90, 100, 25);
        add(btnEliminar);

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(280, 125, 100, 25);
        add(btnLimpiar);

        tabla = new JTable();
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(20, 170, 640, 180);
        add(scroll);

        cargarTabla();

        // === ACCIONES ===
        btnAgregar.addActionListener(e -> agregar());
        btnEditar.addActionListener(e -> editar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiar());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() != -1) {
                idSeleccionado = (int) tabla.getValueAt(tabla.getSelectedRow(), 0);
                txtNombre.setText(tabla.getValueAt(tabla.getSelectedRow(), 1).toString());
                txtTelefono.setText(tabla.getValueAt(tabla.getSelectedRow(), 2).toString());
                txtEmail.setText(tabla.getValueAt(tabla.getSelectedRow(), 3).toString());
                txtDireccion.setText(tabla.getValueAt(tabla.getSelectedRow(), 4).toString());
            }
        });
    }

    private void cargarTabla() {
        String[] columnas = {"ID", "Nombre", "Teléfono", "Email", "Dirección"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        List<Dueno> lista = dao.listar();
        for (Dueno d : lista) {
            Object[] fila = {d.getId(), d.getNombre(), d.getTelefono(), d.getEmail(), d.getDireccion()};
            modelo.addRow(fila);
        }
        tabla.setModel(modelo);
    }

    private void agregar() {
        Dueno d = new Dueno();
        d.setNombre(txtNombre.getText());
        d.setTelefono(txtTelefono.getText());
        d.setEmail(txtEmail.getText());
        d.setDireccion(txtDireccion.getText());
        dao.insertar(d);
        cargarTabla();
        limpiar();
    }

    private void editar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un registro");
            return;
        }
        Dueno d = new Dueno();
        d.setId(idSeleccionado);
        d.setNombre(txtNombre.getText());
        d.setTelefono(txtTelefono.getText());
        d.setEmail(txtEmail.getText());
        d.setDireccion(txtDireccion.getText());
        dao.actualizar(d);
        cargarTabla();
        limpiar();
    }

    private void eliminar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un registro");
            return;
        }
        dao.eliminar(idSeleccionado);
        cargarTabla();
        limpiar();
    }

    private void limpiar() {
        txtNombre.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtDireccion.setText("");
        idSeleccionado = -1;
    }
}
