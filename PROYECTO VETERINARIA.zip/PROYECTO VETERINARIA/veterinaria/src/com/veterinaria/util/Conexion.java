package com.veterinaria.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static final String URL = "jdbc:postgresql://localhost:5432/Veterinaria";
    private static final String USER = "postgres";  // tu usuario
    private static final String PASS = "123";       // tu contraseña real

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (SQLException e) {
            System.out.println("❌ Error de conexión: " + e.getMessage());
            return null;
        }
    }

    // ✅ Alias para compatibilidad con los DAO
    public static Connection conectar() {
        return getConnection();
    }
}

